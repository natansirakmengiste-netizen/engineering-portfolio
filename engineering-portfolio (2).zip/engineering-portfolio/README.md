# Natan Mengiste — Engineering Portfolio

A responsive, clean/minimal HTML, CSS, and JavaScript portfolio homepage.

## Preview
Open `index.html` in a browser, or run `python -m http.server 8000` from this folder.

## Homepage
Personalized name, Aerospace Engineer headline, University of Virginia background, and aerospace / robotics / electronics / manufacturing focus. Four project previews are included.

## Before publishing
- Add verified email, LinkedIn, and GitHub links to the contact section. No personal contact information has been invented.
- Add a resume PDF and a real resume link.
- Replace the illustrated project visuals with your own photographs, CAD images, and diagrams.
- Create individual project case-study pages and link each project card to its page (cards currently navigate to the contact section).
- Review project descriptions and only claim work you personally completed.
